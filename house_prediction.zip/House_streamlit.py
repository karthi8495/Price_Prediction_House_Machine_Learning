import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
from fpdf import FPDF
import io
from datetime import datetime


# load the trained model and label encoders

model_file_path = r"D:\\GUVI AI & ML\\Machine-Learning\\Streamlit_house_prediction\\best_model.pkl"
model = joblib.load(model_file_path)

label_encoder_file_path = r"D:\\GUVI AI & ML\\Machine-Learning\\Streamlit_house_prediction\\label_encoders.pkl"
label_encoders =joblib.load(label_encoder_file_path)


# load the preprocessed dataset for filtering

data_file_path = r"D:\\GUVI AI & ML\\Machine-Learning\\Streamlit_house_prediction\\preprocessed_house_data.csv"
data = pd.read_csv(data_file_path)

# determine expected features from the model (assuming the model has a features importance attributes)

try:
    if hasattr(model,'feature_names_in_'):
        expected_features = model.feature_names_in_.tolist()
    else:
        # use a fallback list if feature names are not available
        expected_features = [
    'AREA', 'INT_SQFT', 'DIST_MAINROAD', 'N_BEDROOM', 'N_BATHROOM',
    'N_ROOM', 'PARK_FACIL', 'BUILDTYPE', 'QS_ROOMS', 'QS_BATHROOM',
    'QS_BEDROOM', 'QS_OVERALL', 'REG_FEE', 'COMMIS',
    'SALE_YEAR', 'SALE_MONTH', 'BUILD_YEAR', 'BUILD_AGE'
]

except Exception as e:
    st.write(f"Error determining feature names: {e}")
    expected_features = []


# Ensure the model expect the columns

st.set_page_config(page_title = "House Price Prediction", layout="wide")
st.title("House Price Prediction")


# Define and display filters
st.sidebar.header("🔍 **Refine Your House Price Prediction**")


# Area filter(use original categories)
area_options = ['Adyar','Anna Nagar','Chrompet','Karapakkam','KK Nagar','TNagar','T Nagar',"Velachery"]
area_filter = st.sidebar.selectbox('🗺️  Area',area_options)

# Bilding type filter
build_types = ['Commercial','House','Others']
build_type_filter = st.sidebar.selectbox('🏢 Building Type',build_types)

# Park Facility filter
park_facil_options=['No','Yes']
park_facil_filter = st.sidebar.selectbox('🌳 Park Facility',park_facil_options)

# Numeric input fields with adjusted ranges
int_sqft = st.number_input("Internal Square Feet",min_value = 0.0)
n_bedroom = st.number_input("Number of Bedrooms",min_value=0)
n_bathroom = st.number_input("Number of Bathrooms",min_value=0)
n_room = st.number_input("Number of Rooms",min_value=0)


# Adjusted range for quality fields
qs_rooms = st.number_input("Quality of Rooms",min_value=0.0,max_value=10.0)
qs_bathroom = st.number_input("Quality of Bathrooms",min_value=0.0,max_value=10.0)
qs_bedroom = st.number_input("Quality of Bedrooms",min_value=0.0,max_value=10.0)
qs_overall = st.number_input("Quality Overall", min_value=0.0,max_value = 10.0)



# Dynamic ranges for sale and build Years
sale_year = st.number_input('📅 Sale Year', min_value=int(data['SALE_YEAR'].min()), max_value=int(data['SALE_YEAR'].max()), 
value = int(data['SALE_YEAR'].max()))

build_year = st.number_input('📅 Build Year', min_value=int(data['BUILD_YEAR'].min()), max_value=int(data['BUILD_YEAR'].max()), 
value = int(data['BUILD_YEAR'].max()))

sale_month = st.number_input('📅 Sale Month',min_value=1,max_value=12)


# Compute Build_AGE
current_year = datetime.now().year
build_age = current_year - build_year

# Placeholder for DIST_MAINROAD(if needed,add this field based on your dataset)
dist_mainroad = 'No'  #placeholder value;adjust on your needs
encoded_dist_mainroad = label_encoders['DIST_MAINROAD'].transform([dist_mainroad])[0] if 'DIST_MAINROAD' in label_encoders else 0

# other numeric input fields
reg_fee = st.number_input("Registeration Fee",min_value=0.0)
commis = st.number_input('Commission', min_value=0.0)

# Encode categorical features using saved label encoders
encoded_area = label_encoders['AREA'].transform([area_filter])[0]
encoded_build_type = label_encoders['BUILDTYPE'].transform([build_type_filter])[0]
encoded_park_facil = label_encoders['PARK_FACIL'].transform([park_facil_filter])[0]

# Prepare input data for prediction

input_data = pd.DataFrame({
    'AREA': [encoded_area],
    'INT_SQFT': [int_sqft],
    'N_BEDROOM': [n_bedroom],
    'N_BATHROOM': [n_bathroom],
    'N_ROOM': [n_room],
    'BUILDTYPE': [encoded_build_type],
    'PARK_FACIL': [encoded_park_facil],
    'QS_ROOMS': [qs_rooms],
    'QS_BATHROOM': [qs_bathroom],
    'QS_BEDROOM': [qs_bedroom],
    'QS_OVERALL': [qs_overall],
    'REG_FEE': [reg_fee],
    'COMMIS': [commis],
    'SALE_YEAR': [sale_year],
    'BUILD_YEAR': [build_year],
    'SALE_MONTH': [sale_month],
    'BUILD_AGE': [build_age],
    'DIST_MAINROAD': [encoded_dist_mainroad]
}, columns=expected_features)  # Ensure all columns are present and in the correct order

# Predict house price
if st.button('🔮 Predict Price'):
    try:
        prediction = model.predict(input_data)
        avg_predicted_price = prediction[0]
        
        # Display the prediction
        st.markdown(f"### **Predicted House Price**")
        st.markdown(f"<h1 style='color: maroon;'>{avg_predicted_price:,.2f} INR</h1>", unsafe_allow_html=True)
        
        # Generate a report
        report = f"""
         House Sale Report for Chennai
        
        Details:
        
        - Area: {area_filter}
        - Internal Square Feet: {int_sqft}
        - Number of Bedrooms: {n_bedroom}
        - Number of Bathrooms: {n_bathroom}
        - Building Type: {build_type_filter}
        - Park Facility: {park_facil_filter}
        - Quality of Rooms (0-10): {qs_rooms}
        - Quality of Bathroom (0-10): {qs_bathroom}
        - Quality of Bedroom (0-10): {qs_bedroom}
        - Overall Quality (0-10): {qs_overall}
        - Registration Fee (INR): {reg_fee}
        - Commission (INR): {commis}
        - Sale Year: {sale_year}
        - Build Year: {build_year}
        - Build Age: {build_age}
        - Sale Month: {sale_month}
        - Distance to Main Road: {dist_mainroad}
        
        Predicted House Price for the Applied User Data: {avg_predicted_price:,.2f} INR
        """

        # Create and download image report
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.text(0.5, 0.5, report, fontsize=12, va='center', ha='center', wrap=True)
        ax.axis('off')
        image_file = io.BytesIO()
        plt.savefig(image_file, format='png')
        plt.close(fig)
        image_file.seek(0)
        
        st.download_button(
            label="📷 Download Report as Image",
            data=image_file,
            file_name="house_price_prediction_report.png",
            mime="image/png"
        )

        # Create and download PDF report
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.multi_cell(0, 10, report)
        
        # Save PDF to a temporary file
        pdf_file_path = "temp_report.pdf"
        pdf.output(pdf_file_path)
        
        # Read the PDF file into a BytesIO object
        with open(pdf_file_path, "rb") as f:
            pdf_file = io.BytesIO(f.read())
        
        st.download_button(
            label="📄 Download Report as PDF",
            data=pdf_file,
            file_name="house_price_prediction_report.pdf",
            mime="application/pdf"
        )
    except Exception as e:
        st.write(f"Error in prediction: {e}")
